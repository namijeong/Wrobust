.onAttach <- function(...){
  packageStartupMessage("\n rQCC Package is installed. \n\n")
}
